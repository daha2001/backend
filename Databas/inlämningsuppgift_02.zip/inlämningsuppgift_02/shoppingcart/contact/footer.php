</main>
        <footer>
            <div class="content-wrapper">
                <p style="text-align: center">&copy; 2021, Marcus Ljungqvist, Daniel Håkansson</p>
            </div>
        </footer>
        <script src="script.js"></script>
    </body>
</html>