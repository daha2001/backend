<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>webshop</title>
		<link href="../style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body>
        <header>
            <div class="content-wrapper">
                <h1>webshop</h1>
                <nav>
                    <a href="../index.php">Startsida</a>
                    <a href="../index.php?page=products">Produkter</a>
                    <a href="contact.php">Kontakta oss</a>

                </nav>

					</a>
                </div>
            </div>
        </header>
        <main>