<?php

require_once 'databas.php';
require_once 'header.php';


?>



<?php


require_once 'skapa.php'
?>


<?php

require_once 'footer.php'

?>